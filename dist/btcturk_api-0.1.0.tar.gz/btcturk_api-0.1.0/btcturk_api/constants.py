CURRENCY_SYMBOLS = ['TRY']
CRYPTO_SYMBOLS = ['BTC', 'EOS', 'ETH', 'DASH', 'ATOM', 'USDT', 'LTC', 'XLM', 'XRP', 'NEO', 'LINK']
TRADE_TYPES = ['buy', 'sell']
DEPOSIT_OR_WITHDRAWAL = ['deposit', 'withdrawal']
